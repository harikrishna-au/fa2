# Reconstruction notes

## Source coverage

| Source | Pages | Recovered content |
|---|---:|---|
| Code photos | 1–10 | P1 state, four evidence entries, TODO contracts, driver and two tests |
| Code photos | 11–16 | P2 language, state, three node TODOs, graph, checkpoint/replay driver, article |
| Question photos | 1–7 | General instructions, P1 scenario, node/tool contracts, 40 marks, samples |
| Question photos | 7–12 | P2 scenario, checkpoint/replay requirements, naming contract, 20 marks |

All 28 pages were visually reviewed. Overlapping photos were consolidated.
The original PDFs are included unchanged for checking wording.

## What was reconstructed

- The first visible code lines are P1 line 26 and P2 line 23. File headers,
  imports and dotenv setup above those lines were not visible and were recreated.
- Some TODOs in P1 contain a student's partial implementation. They were reset
  to incomplete stubs, including the LLM, tools, registration, classification
  and tool-dispatch sections. Those attempted answers are not a reference solution.
- Function signatures and NotImplementedError placeholders make blank sections
  valid Python. All required function, graph-node and state names are retained.
- The standalone `Predefined Evidence Datasets.txt` and original syntax reference
  were mentioned but not attached. Replacements are included.
- Long evidence lines are clipped at the right edge of code page 2. Short endings
  were completed for the Bloomberg solar-installations line, World Bank
  post-Q2-2024 line and Financial Times declining-inflation line. These endings
  cannot be claimed as exact transcriptions. Ocean and AI-job lines were also
  cross-checked against question pages 6–7; the code's third AI evidence item is
  retained although the sample output only displays two.
- The P2 article's `years,` and final sentence punctuation are clipped in code
  page 16 and have been completed naturally. Its visible numbers and meaning
  are preserved: 50 electric buses, three metro lines, two years.
- Degree-symbol notation in evidence was normalized to `degrees Celsius`.
- The question PDF in this pack is a clean restatement, not a photographic or
  word-for-word reproduction. No subtask marks or official timing were invented.
- Requirements, setup checker, .env example, README and self-check are added
  practice aids, not recovered official files.

## Clarifications that matter

1. P1 function `decide_and_invoke_tool` is graph node `retrieve_evidence`;
   function `generate_final_report` is graph node `finalize_report`.
2. P1 tools return a dictionary containing an evidence list. The state stores
   the whole dictionary: `state['evidence']['evidence']` reaches that list.
3. Confidence is support for the claim in this exercise. The original sample
   values 0.59 and 0.81 are illustrative LLM outputs, not exact required constants.
   Do not hard-code sample scores to force the routes.
4. The paper calls checkpoints persistent but explicitly requires InMemorySaver.
   This retains state during the current process; it does not survive a restart.
   No SQLite/Postgres database is needed for this reconstruction.
5. P2 asks for replay of an existing V1 checkpoint. Editing state/forking is not
   required. Replayed summaries can differ; the preserved translation should not
   be regenerated.
6. The sample P1 human approval wording is illustrative. Actual reports should
   reflect the reviewer input, including rejection, rather than always approving.
7. Fixed evidence is exercise material, not independently verified research.

## Verification limits

Local checks cover syntax, required names, data consistency, source PDF identity,
PDF layout and archive integrity. No live AWS call was made, no credentials were
available, and dependency installation/live compatibility was not certified.
