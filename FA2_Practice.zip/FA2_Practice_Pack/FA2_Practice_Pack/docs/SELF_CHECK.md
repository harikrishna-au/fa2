# After-attempt self-check

This checklist is a practice aid, not an official grader. Only the total problem
marks (40 and 20) are visible in the source. Exact LLM prose/scores can vary.

## P1 — 40 marks

- [ ] Both @tool functions return the proper evidence dictionary for every matching key.
- [ ] An unknown query returns an explanatory list, not a string or invented evidence.
- [ ] All four data entries are present and exact claim text reaches the lookup.
- [ ] Classification uses the LLM and returns one of the three required labels.
- [ ] Tool selection uses the bound LLM, inspects tool_calls, and executes one tool.
- [ ] Environmental calls use climate_data_tool; the other two use general_fact_tool.
- [ ] Missing/invalid tool calls are handled deliberately.
- [ ] Verifier uses the evidence and produces a numeric score in [0, 1].
- [ ] Confidence 0.70 takes the automatic path; 0.69 takes human review.
- [ ] The human-review node uses interrupt with claim/evidence/confidence.
- [ ] Resume uses Command and the same graph/thread; feedback is saved in state.
- [ ] The automatic route never prompts for human feedback.
- [ ] The final report contains all six specified elements and reflects the evidence.
- [ ] Both original samples run on distinct thread IDs.
- [ ] Function-to-node name mappings, checkpointing and graph display are correct.

### Source examples (illustrative outputs)

| Claim | Category | Tool | Source sample score | Expected source route |
|---|---|---|---:|---|
| AI replaced 40% of human jobs in 2024 | Technological | general_fact_tool | 0.59 | Human review |
| Ocean temperatures hit record highs in 2024 | Environmental | climate_data_tool | 0.81 | Auto verification |

The first example supplies reviewer feedback `Verified after manual review.` and
shows `Verified (Human Approved)` with a conclusion that the claim is exaggerated /
partially true. The second concludes the claim is supported. Do not turn these
illustrative sentences into unconditional approval logic.

Additional provided-data practice: classify the renewable-energy claim as
Environmental and the inflation claim as Economic. There are no source-prescribed
confidence scores for them. Use separate thread IDs for independent claims.

## P2 — 20 marks

- [ ] Formal translation is in Hindi or French, controlled by TARGET_LANGUAGE.
- [ ] Summarization consumes translated text, not source_text.
- [ ] Refinement consumes summary and preserves that summary's facts and language.
- [ ] Sample details remain accurate: 50 buses, three metro lines, two years.
- [ ] Graph nodes run in the required order and save checkpoints.
- [ ] history shows snapshot next values and checkpoint identifiers.
- [ ] v1 identifies the point after translation and before summarization.
- [ ] The selected V1 translation and checkpoint ID are printed.
- [ ] Replay uses None plus the saved checkpoint config.
- [ ] Replay runs summarize_text and refine_summary again, without translating again.
- [ ] Regenerated summary and refined text are printed.
- [ ] The same app/checkpointer is used throughout the demonstration.

For local debugging, temporarily log node entry to confirm the replay order.
Identical regenerated wording does not prove replay failed; deterministic LLM
settings can yield the same text. Check execution traces and checkpoint IDs.
